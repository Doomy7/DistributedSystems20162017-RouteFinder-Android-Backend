import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import org.json.simple.parser.ParseException;

public class waitForTasksThread extends Thread{

	waitForTasksThread() throws IOException, ClassNotFoundException, InterruptedException, ParseException{
		boolean ok = false;
		String command = null;
		while(!ok)
		{
			try{	
				command = (String) Worker.masterInput.readObject();
				if(command.equals("StartCache") || command.equals("API")) ok = true;
			}catch(Exception e){
				e.printStackTrace();
				System.exit(0);
			}
		}
		if ( command.equals( "StartCache" ) )
		{
			System.out.println( "Worker with id: 0 started searching in cache\n##############################" );
			double[] keyFloor = (double[]) Worker.masterInput.readObject();
			List<List<HashMap<String,String>>> result = WorkerDBFile.workerDB.lookUp(keyFloor);
		
			if(result != null)
			{
				System.out.println( "Worker with id: 0 searched his cache, sent results to reducer and ACK to master\n##############################" );
				Worker.reducerOutput.writeObject(keyFloor);
				Worker.reducerOutput.flush();
				
				Worker.reducerOutput.writeObject(result);
				Worker.reducerOutput.flush();
				
				Worker.masterOutput.writeObject("Worker0SearchedCache");
				Worker.masterOutput.flush();
			}
			else{
				System.out.println("Worker with id: 0 searched his cache, sent null to reducer and ACK to master\n##############################");
				Worker.reducerOutput.writeObject(keyFloor);
				Worker.reducerOutput.flush();
				
				Worker.reducerOutput.writeObject(null);
				Worker.reducerOutput.flush();
				
				Worker.masterOutput.writeObject("Worker0SearchedCache");
				Worker.masterOutput.flush();	
			}		
		}
		else if ( command.equals( "API" ) )
		{
			System.out.println("Worker with id: 0 searches API\n##############################");
			double[] floorKey = (double[]) Worker.masterInput.readObject();
			double[] fullKey = (double[]) Worker.masterInput.readObject();
			List<List<HashMap<String, String>>> routes = RoutesGoogleAPI.getRoutes(fullKey);
			WorkerDBFile.workerDB.store(floorKey, routes);		
			Worker.masterOutput.writeObject("doneSearchAPI");
			Worker.masterOutput.flush();
			Worker.masterOutput.writeObject(routes);
			Worker.masterOutput.flush();
			System.out.println("Worker with id: 0 finished with API and sent results to Master\n##############################");

		}
	}
}
