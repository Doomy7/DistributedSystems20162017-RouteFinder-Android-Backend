import java.io.*;
import java.net.*;

import org.json.simple.parser.ParseException;


public class Worker extends Thread{

	public static void main(String args[]) throws IOException, ClassNotFoundException, ParseException, InterruptedException {
		new Worker().startRunning();
	}
	
	private ServerSocket workerSocket;
	
	private Socket masterConnection;
	static ObjectInputStream masterInput;
	static ObjectOutputStream masterOutput;
	
	private Socket reducerConnection;
	private ObjectInputStream reducerInput;
	static ObjectOutputStream reducerOutput;
	
	
	
	
	public void startRunning() throws IOException, ClassNotFoundException, ParseException, InterruptedException{
		initialize();
		connectToMaster();
		connectToReducer();

		synchronized(WorkerDBFile.workerDB){
			try{
				while(true){
					try{	
							System.out.println( "Worker with id: 0 is waiting\n##############################" );
							Thread t = new waitForTasksThread();
							t.start();
					}catch(EOFException eofException){
						System.out.println("\nServer ended connection\n");
					}
				}
			}catch(IOException ioException){
				ioException.printStackTrace();
			}finally{
				try{
					workerSocket.close();
					System.out.println("Closing Main Server Connection\n");
				}catch(IOException ioException){
					ioException.printStackTrace();
				}
			}	
		}
	}

	private void initialize() throws IOException, ClassNotFoundException {
		workerSocket = new ServerSocket(8000,200);
		System.out.println("Worker with id: 0 is up\n###############################");
	} //initialize
	
	private void connectToMaster() throws ClassNotFoundException, IOException {		
			masterConnection = new Socket("127.0.0.1",7000);
			masterOutput = new ObjectOutputStream(masterConnection.getOutputStream());
			masterOutput.writeObject("WorkerIsReady");
			masterOutput.flush();
			int id = 0;
			masterOutput.writeObject(id);
			masterOutput.flush();
			masterInput = new ObjectInputStream(masterConnection.getInputStream());
			String ack = (String) masterInput.readObject();
			if ( ack.equals( "WorkerAccepted" ) )
			{
				System.out.println("Worker with id: 0 connected with Master"
						+ "\n###############################");
			}				
	} //connectToMaster

	private void connectToReducer() throws UnknownHostException, IOException, ClassNotFoundException {
		reducerConnection = new Socket("127.0.0.1",8003);
		reducerOutput = new ObjectOutputStream(reducerConnection.getOutputStream());
		reducerOutput.writeObject("WorkerIsReady");
		reducerOutput.flush();
		int id = 0;
		reducerOutput.writeObject(id);
		reducerOutput.flush();
		reducerInput = new ObjectInputStream(reducerConnection.getInputStream());
		String ack = (String) reducerInput.readObject();
		if ( ack.equals ( "WorkerAccepted" ) )
		{
			System.out.println( "Worker with id: 0 connected with Reducer"
					+ "\n###############################" );
		}
	} //connectToReducer

}
