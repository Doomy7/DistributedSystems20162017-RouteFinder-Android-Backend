public class DBEntry<K,V> {

	K latlngPair;
	V routeList;
	DBEntry<K,V> next,before,after;
	
	DBEntry(K latlngPair, V routeList, DBEntry<K,V> next){
		this.latlngPair = latlngPair;
		this.routeList = routeList;
		this.next = next;
	}
	
	K getKey(){
		return latlngPair;
	}
	
	V getRouteList(){
		return routeList;
	}
}
