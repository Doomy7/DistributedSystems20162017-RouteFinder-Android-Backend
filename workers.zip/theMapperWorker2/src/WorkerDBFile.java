import java.util.HashMap;
import java.util.List;

public class WorkerDBFile {
	static WorkerDB<double[],List<List<HashMap<String,String>>>> workerDB = new WorkerDB<>(50);
}
